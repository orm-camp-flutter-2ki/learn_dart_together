import '../model/user.dart';

class UserDate {
  List<User> userList = [];
  int userId = 0;
}
