abstract interface class View {
  void getView();
}
